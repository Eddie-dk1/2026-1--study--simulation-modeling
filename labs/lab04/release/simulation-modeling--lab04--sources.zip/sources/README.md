# Исходные материалы ЛР4

В папке находятся исходные markdown-файлы для формирования отчёта и презентации.

- `../report-lab4.md`
- `../presentation-lab4.md`
- `../lms-answer-template.md`
- `../check-list.md`
