using DrWatson
@quickactivate "SimulationModelingLab07"

include(srcdir("SimulationModelingLab07.jl"))
using .SimulationModelingLab07

customers, trace, summary, sweep = save_mmc_outputs(projectdir())

println(summary)
println(first(sweep, 8))