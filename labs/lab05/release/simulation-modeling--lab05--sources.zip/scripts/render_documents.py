from __future__ import annotations

from pathlib import Path
from textwrap import wrap

import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages


ROOT = Path(__file__).resolve().parent.parent
REPORT_DIR = ROOT / "report"
PRESENTATION_DIR = ROOT / "presentation"
PLOTS_DIR = ROOT / "plots"


def draw_title_page(pdf: PdfPages, title: str, subtitle: str, author: str, date: str, *, wide: bool = False) -> None:
    figsize = (13.33, 7.5) if wide else (8.27, 11.69)
    fig = plt.figure(figsize=figsize)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.axis("off")
    fig.patch.set_facecolor("#f7f4ee")
    ax.text(0.5, 0.72, title, ha="center", va="center", fontsize=26 if wide else 24, fontweight="bold")
    ax.text(0.5, 0.60, subtitle, ha="center", va="center", fontsize=20 if wide else 18)
    ax.text(0.5, 0.42, author, ha="center", va="center", fontsize=16)
    ax.text(0.5, 0.36, "Российский университет дружбы народов", ha="center", va="center", fontsize=14)
    ax.text(0.5, 0.30, date, ha="center", va="center", fontsize=13)
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def draw_text_page(
    pdf: PdfPages,
    title: str,
    paragraphs: list[str] | None = None,
    bullets: list[str] | None = None,
    *,
    wide: bool = False,
) -> None:
    figsize = (13.33, 7.5) if wide else (8.27, 11.69)
    fig = plt.figure(figsize=figsize)
    ax = fig.add_axes([0.06, 0.05, 0.88, 0.9])
    ax.axis("off")
    fig.patch.set_facecolor("white")
    ax.text(0.0, 0.98, title, ha="left", va="top", fontsize=22 if wide else 20, fontweight="bold")

    y = 0.90
    width = 90 if wide else 65
    step = 0.048 if wide else 0.035

    for paragraph in paragraphs or []:
        for line in wrap(paragraph, width=width):
            ax.text(0.0, y, line, ha="left", va="top", fontsize=13 if wide else 11)
            y -= step
        y -= step * 0.6

    for bullet in bullets or []:
        for i, line in enumerate(wrap(bullet, width=width - 3)):
            prefix = "• " if i == 0 else "  "
            ax.text(0.02, y, prefix + line, ha="left", va="top", fontsize=13 if wide else 11)
            y -= step
        y -= step * 0.25

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def draw_image_page(
    pdf: PdfPages,
    title: str,
    image_path: Path,
    caption: str,
    bullets: list[str] | None = None,
    *,
    wide: bool = False,
) -> None:
    figsize = (13.33, 7.5) if wide else (8.27, 11.69)
    fig = plt.figure(figsize=figsize)
    ax_title = fig.add_axes([0.06, 0.92, 0.88, 0.06])
    ax_title.axis("off")
    ax_title.text(0.0, 0.5, title, ha="left", va="center", fontsize=22 if wide else 20, fontweight="bold")

    if wide:
        ax_img = fig.add_axes([0.06, 0.18, 0.56, 0.68])
        ax_text = fig.add_axes([0.66, 0.18, 0.28, 0.68])
    else:
        ax_img = fig.add_axes([0.08, 0.38, 0.84, 0.48])
        ax_text = fig.add_axes([0.08, 0.08, 0.84, 0.22])

    ax_text.axis("off")
    image = mpimg.imread(image_path)
    ax_img.imshow(image)
    ax_img.axis("off")

    y = 1.0
    width = 34 if wide else 75
    step = 0.09 if wide else 0.16
    ax_text.text(0.0, y, caption, ha="left", va="top", fontsize=12 if wide else 11)
    y -= step

    for bullet in bullets or []:
        for i, line in enumerate(wrap(bullet, width=width)):
            prefix = "• " if i == 0 else "  "
            ax_text.text(0.0, y, prefix + line, ha="left", va="top", fontsize=12 if wide else 11)
            y -= step * 0.8
        y -= step * 0.15

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def draw_two_image_page(
    pdf: PdfPages,
    title: str,
    left_path: Path,
    right_path: Path,
    left_caption: str,
    right_caption: str,
) -> None:
    fig = plt.figure(figsize=(8.27, 11.69))
    ax_title = fig.add_axes([0.06, 0.92, 0.88, 0.06])
    ax_title.axis("off")
    ax_title.text(0.0, 0.5, title, ha="left", va="center", fontsize=20, fontweight="bold")

    for x, path, caption in [
        (0.08, left_path, left_caption),
        (0.08, right_path, right_caption),
    ]:
        pass

    axes = [
        (fig.add_axes([0.08, 0.55, 0.84, 0.28]), left_path, left_caption),
        (fig.add_axes([0.08, 0.18, 0.84, 0.28]), right_path, right_caption),
    ]
    for ax, path, caption in axes:
        ax.imshow(mpimg.imread(path))
        ax.axis("off")
        ax.text(0.0, -0.08, caption, transform=ax.transAxes, ha="left", va="top", fontsize=11)

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def render_report() -> None:
    report_pdf = REPORT_DIR / "report.pdf"
    with PdfPages(report_pdf) as pdf:
        draw_title_page(
            pdf,
            "Имитационное моделирование",
            "Лабораторная работа №5. Аппарат сетей Петри",
            "Гашимов Кенан Мухтар оглы",
            "2026-04-18",
        )
        draw_text_page(
            pdf,
            "Цель и задание",
            paragraphs=[
                "Цель работы состоит в изучении сетей Петри на примере задачи обедающих философов, "
                "выявлении взаимной блокировки в классической постановке и устранении deadlock с помощью арбитра."
            ],
            bullets=[
                "Реализовать классическую и модифицированную сеть Петри.",
                "Выполнить стохастическое и детерминированное моделирование.",
                "Сохранить CSV-таблицы, графики, GIF-анимацию и literate-артефакты.",
                "Провести параметрическое исследование по N, tmax и seed.",
            ],
        )
        draw_text_page(
            pdf,
            "Теоретическое введение",
            paragraphs=[
                "Сеть Петри описывает дискретную систему через позиции, переходы, дуги и маркировку. "
                "В задаче обедающих философов позиции представляют состояния философов и свободные вилки, "
                "а переходы моделируют захват и освобождение ресурсов.",
                "В классической постановке каждый философ может взять левую вилку и застрять в ожидании правой. "
                "Это приводит к тупиковой маркировке, когда все философы находятся в состоянии Hungry.",
            ],
            bullets=[
                "Классическая сеть приводит к deadlock.",
                "Позиция Arbiter ограничивает число одновременных попыток захвата вилок.",
                "Стохастическое моделирование подтверждает тупиковое и нетупиковое поведение.",
            ],
        )
        draw_text_page(
            pdf,
            "Структура проекта и артефакты",
            bullets=[
                "src/DiningPhilosophers.jl — описание сети Петри и методов моделирования.",
                "scripts/dining_philosophers.jl — базовый эксперимент.",
                "scripts/dining_philosophers_animation.jl — построение GIF-анимации.",
                "scripts/dining_philosophers_report.jl — итоговый сравнительный график по состояниям Eat_i.",
                "scripts/dining_philosophers_params.jl — параметрическое исследование.",
                "generated/ — clean, md, ipynb и qmd представления literate-скриптов.",
            ],
        )
        draw_image_page(
            pdf,
            "Результаты для классической сети",
            PLOTS_DIR / "classic_simulation.png",
            "Базовый прогон для классической сети завершился тупиковой маркировкой.",
            bullets=[
                "deadlock = true",
                "число состояний = 9",
                "final_hungry = 5",
                "final_eat = 0",
                "t_deadlock ≈ 2.27",
            ],
        )
        draw_image_page(
            pdf,
            "Результаты для сети с арбитром",
            PLOTS_DIR / "arbiter_simulation.png",
            "Модифицированная сеть с арбитром сохраняет активность на всём интервале моделирования.",
            bullets=[
                "deadlock = false",
                "число состояний = 76",
                "final_hungry = 3",
                "final_eat = 1",
                "модель остаётся живой до t = 50.0",
            ],
        )
        draw_two_image_page(
            pdf,
            "Детерминированные траектории",
            PLOTS_DIR / "classic_deterministic.png",
            PLOTS_DIR / "arbiter_deterministic.png",
            "Классическая детерминированная модель",
            "Детерминированная модель с арбитром",
        )
        draw_image_page(
            pdf,
            "Итоговый сравнительный график",
            PLOTS_DIR / "final_report.png",
            "Сравнение состояний Eat_i показывает принципиальную разницу между двумя постановками.",
            bullets=[
                "в классической сети все Eat_i быстро опускаются к нулю",
                "в сети с арбитром состояния Eat_i появляются до конца интервала",
            ],
        )
        draw_image_page(
            pdf,
            "Параметрическое исследование",
            PLOTS_DIR / "dining_params.png",
            "Проверка по 54 сериям запусков подтверждает устойчивость результата.",
            bullets=[
                "classic: 27 deadlock из 27 запусков",
                "arbiter: 0 deadlock из 27 запусков",
                "для классической сети final_eat всегда равен 0",
                "для arbiter в конце часто сохраняется хотя бы один Eat_i",
            ],
        )
        draw_text_page(
            pdf,
            "Выводы",
            paragraphs=[
                "В лабораторной работе была реализована сеть Петри для задачи обедающих философов, "
                "выполнены стохастическое и детерминированное моделирование, получены CSV-таблицы, "
                "графики, анимация и literate-представления.",
                "Классическая сеть во всех проверенных сериях приходит к deadlock, тогда как введение "
                "арбитра устраняет тупиковую конфигурацию и сохраняет живость модели.",
            ],
        )


def render_presentation() -> None:
    presentation_pdf = PRESENTATION_DIR / "presentation.pdf"
    with PdfPages(presentation_pdf) as pdf:
        draw_title_page(
            pdf,
            "Имитационное моделирование",
            "Лабораторная работа №5. Аппарат сетей Петри",
            "Гашимов Кенан Мухтар оглы",
            "2026-04-18",
            wide=True,
        )
        draw_text_page(
            pdf,
            "Цель и задачи",
            bullets=[
                "изучить задачу обедающих философов в терминах сетей Петри",
                "воспроизвести deadlock в классической постановке",
                "устранить блокировку с помощью арбитра",
                "получить графики, таблицы, GIF и literate-артефакты",
            ],
            wide=True,
        )
        draw_text_page(
            pdf,
            "Структура проекта",
            bullets=[
                "src/DiningPhilosophers.jl — модуль модели",
                "базовый сценарий, анимация, итоговый график, параметрический анализ",
                "generated/clean, generated/md, generated/notebooks, generated/qmd",
            ],
            wide=True,
        )
        draw_image_page(
            pdf,
            "Классическая сеть",
            PLOTS_DIR / "classic_simulation.png",
            "Классическая сеть быстро приходит к тупиковой маркировке.",
            bullets=[
                "deadlock = true",
                "final_hungry = 5",
                "final_eat = 0",
            ],
            wide=True,
        )
        draw_image_page(
            pdf,
            "Сеть с арбитром",
            PLOTS_DIR / "arbiter_simulation.png",
            "Арбитр не позволяет всем философам одновременно захватить по одной вилке.",
            bullets=[
                "deadlock = false",
                "final_hungry = 3",
                "final_eat = 1",
            ],
            wide=True,
        )
        draw_image_page(
            pdf,
            "Сравнение состояний Eat_i",
            PLOTS_DIR / "final_report.png",
            "На итоговом графике хорошо видно, что активность в классической сети исчезает.",
            bullets=[
                "верхняя панель — классическая сеть",
                "нижняя панель — сеть с арбитром",
            ],
            wide=True,
        )
        draw_image_page(
            pdf,
            "Параметрическое исследование",
            PLOTS_DIR / "dining_params.png",
            "Результат устойчив для всех проверенных значений N, tmax и seed.",
            bullets=[
                "classic: 27/27 deadlock",
                "arbiter: 0/27 deadlock",
            ],
            wide=True,
        )
        draw_text_page(
            pdf,
            "Основные артефакты",
            bullets=[
                "data/dining_classic.csv",
                "data/dining_arbiter.csv",
                "data/dining_params.csv",
                "plots/philosophers_simulation.gif",
                "generated/clean, md, ipynb, qmd",
            ],
            wide=True,
        )
        draw_text_page(
            pdf,
            "Выводы",
            bullets=[
                "сети Петри наглядно описывают конкуренцию за ресурсы",
                "классическая постановка приводит к deadlock",
                "арбитр устраняет тупиковую конфигурацию",
                "результат подтверждён базовым и параметрическим экспериментами",
            ],
            wide=True,
        )


def main() -> None:
    REPORT_DIR.mkdir(exist_ok=True)
    PRESENTATION_DIR.mkdir(exist_ok=True)
    render_report()
    render_presentation()
    print(f"Saved {REPORT_DIR / 'report.pdf'}")
    print(f"Saved {PRESENTATION_DIR / 'presentation.pdf'}")


if __name__ == "__main__":
    main()
